module.exports = {

    MAIL_FROM: 'fs@support.org',
    SIGN_UP_MAIL_SUBJECT: 'Activate Account',
    SIGN_UP_TEXT: 'Please click here to verify your email',
    SEND_OTP_TEXT: 'Please enter this six digit code for login.',
    SEND_OTP_SUBJECT: 'OTP Credentials',
    JWT_SECRET: 'secret'
};